This is the builder for the bot. Below is a virus scan (created on a non-distributing scanner):
http://v2.scan.majyx.net/?page=results&sid=472810

Please keep in mind that the output bin is not FUD, and I don't expect it to be. To preserve it's current detection ratio, please only use sites that do not distribute samples. This means <b>DO NOT SCAN ON VIRUSTOTAL</b>.

Some of the safe scanners you can use (non-distributing) are:<br>
http://v2.scan.majyx.net/<br>
http://nodistribute.com<br>
http://fuckingscan.me<br>
http://hidemyfile.biz<br>
http://razorscanner.com<br>
http://scan4you.net<br>
https://anonscanner.com<br>
https://www.avdetect.com/<br>

If the site you wish to scan at is <b>not</b> listed here, <b>you probably shouldn't use it to scan malware</b>.
